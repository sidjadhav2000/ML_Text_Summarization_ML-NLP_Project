#-------------------------------------------------------------------------------------------

"""
import os
import requests
from flask import Flask, render_template, request
from werkzeug.utils import secure_filename

app = Flask(__name__)

API_URL = "https://api-inference.huggingface.co/models/sshleifer/distilbart-cnn-12-6"
HEADERS = {"Authorization": f"Bearer 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"}
MIN_LENGTH = 30
MAX_LENGTH = 70

# Set the upload folder and allowed extensions
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'docx'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Function to check if the file extension is allowed
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

def summarize_text(text):
    payload = {
        "inputs": text,
        "parameters": {"min_length": MIN_LENGTH, "max_length": MAX_LENGTH}
    }
    response = requests.post(API_URL, headers=HEADERS, json=payload)
    if response.status_code == 200:
        # Check if response content is a list
        if isinstance(response.json(), list):
            # If it's a list, return the first item
            return response.json()[0]
        else:
            # If it's not a list, assume it's a dictionary and return the value of 'summary_text'
            return response.json().get("summary_text")
    else:
        return None  # Return None on error

@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        # Check if text data is provided
        data = request.form.get("data")
        if data:
            summarized_text = summarize_text(data)
            if summarized_text:
                return render_template("home.html", result=summarized_text)
            else:
                return render_template("home.html", error="Failed to summarize text")
        else:
            # Check if file is uploaded
            if 'file' not in request.files:
                return render_template("home.html", error="No file part")
                
            file = request.files['file']

            # Check if file is empty
            if file.filename == '':
                return render_template("home.html", error="No selected file")

            # Check if file and its extension are allowed
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)

                # Read text from uploaded file
                with open(file_path, 'r') as file:
                    data = file.read()

                # Summarize the text
                summarized_text = summarize_text(data)

                if summarized_text:
                    return render_template("home.html", result=summarized_text)
                else:
                    return render_template("home.html", error="Failed to summarize text")
            else:
                return render_template("home.html", error="File type not allowed")
    else:
        return render_template("home.html")

if __name__ == "__main__":
    app.run(debug=True, use_reloader=True)"""


#-----------------------------------------------------------------------------------------------

import os
import requests
from sqlite3 import*
from flask import*
from hashlib import md5
from werkzeug.utils import secure_filename
# from rouge import Rouge

app = Flask(__name__)
app.secret_key = "sid"

# Configuration for Hugging Face Summarization API
API_URL = "https://api-inference.huggingface.co/models/sshleifer/distilbart-cnn-12-6"
HEADERS = {"Authorization": f"Bearer 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"}

# Default summarization parameters
DEFAULT_MIN_LENGTH = 30
DEFAULT_MAX_LENGTH = 70

# Set the upload folder and allowed extensions
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'docx'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Function to check if the file extension is allowed
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Function to summarize text using Hugging Face API
def summarize_text(text, min_length=DEFAULT_MIN_LENGTH, max_length=DEFAULT_MAX_LENGTH , language="en"):
    payload = {
        "inputs": text,
        "parameters": {"min_length": min_length, "max_length": max_length}
    }
    
    response = requests.post(API_URL, headers=HEADERS, json=payload)
    if response.status_code == 200:
        if isinstance(response.json(), list):
            return response.json()[0]
        else:
            return response.json().get("summary_text")
    else:
        return None
    
# Function to compute ROUGE scores
# def calculate_rouge_scores(reference_summary, generated_summary):
#     rouge = Rouge()
#     scores = rouge.get_scores(generated_summary, reference_summary)
#     return scores

# Function to save feedback in the database
def save_feedback(feedback):
    conn = connect('feedback.db')
    c = conn.cursor()
    c.execute("INSERT INTO feedback (message) VALUES (?)", (feedback,))
    conn.commit()
    conn.close()

@app.route("/", methods=["GET", "POST"])
def home():
    if "un" not in session:
        return redirect(url_for("login"))
    elif request.method == "POST" and "logout" in request.form:
        session.pop("un")
        return redirect(url_for("login"))
    else:
        un = session.get("un")
        if un:
            # Check if text data is provided
            data = request.form.get("data")
            if data:
                min_length = int(request.form.get("min_length", DEFAULT_MIN_LENGTH))
                max_length = int(request.form.get("max_length", DEFAULT_MAX_LENGTH))
                language = request.form.get("language", "en")
                summarized_text = summarize_text(data, min_length=min_length, max_length=max_length, language=language)
                if summarized_text:
                    return render_template("home.html", result=summarized_text)
                else:
                    return render_template("home.html", error="Failed to summarize text")
            else:
                # Check if file is uploaded
                if 'file' not in request.files:
                    return render_template("home.html", error="No file part")

                file = request.files['file']

                # Check if file is empty
                if file.filename == '':
                    return render_template("home.html", error="No selected file")

                # Check if file and its extension are allowed
                if file and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    file.save(file_path)

                    # Read text from uploaded file
                    with open(file_path,'r', encoding='iso-8859-1') as file:
                        data = file.read()




                    # Get custom summarization parameters
                    min_length = int(request.form.get("min_length", DEFAULT_MIN_LENGTH))
                    max_length = int(request.form.get("max_length", DEFAULT_MAX_LENGTH))
                    language = request.form.get("language", "en")

                    # Summarize the text
                    summarized_text = summarize_text(data, min_length=min_length, max_length=max_length, language=language)

                    if summarized_text:
                        return render_template("home.html", result=summarized_text)
                    else:
                        return render_template("home.html", error="Failed to summarize text")
                else:
                    return render_template("home.html", error="File type not allowed")
        else:
            return render_template("home.html")


        

@app.route("/login", methods=["GET","POST"])
def login():
	if "un" in session:
		return redirect(url_for("home"))
	elif request.method == "POST":
		un= request.form["un"]
		pw = request.form["pw"]
		epw = md5(pw.encode()).hexdigest()
		con = None
		try:
			con = connect("auth.db")
			cursor = con.cursor()
			sql = "select * from users where un = '%s' and pw = '%s'"
			cursor.execute(sql%(un,epw))
			data= cursor.fetchall()
			if len(data) == 0:
				msg = "Invalid login"
				return render_template("login.html", msg=msg)
			else:
				session["un"]=un
				return redirect(url_for("home"))
		except Exception as e:
			msg = "issue" +str(e)
			return render_template("signup.html", msg=msg)
		finally:
			if con is not None:
				con.close()
	else:
		return render_template("login.html")
     
@app.route("/signup", methods=["GET","POST"])
def signup():
	if "un" in session:
		return redirect(url_for("home"))
	elif request.method == "POST":
		un= request.form["un"]
		pw1 = request.form["pw1"]
		pw2 = request.form["pw2"]
		epw = md5(pw1.encode()).hexdigest()
		if pw1 == pw2:
			con = None
			try:
				con = connect("auth.db")
				cursor = con.cursor()
				sql = "insert into users values('%s','%s')"
				cursor.execute(sql%(un,epw))
				con.commit()
				return redirect(url_for("login"))
			except Exception as e:
				con.rollback()
				msg = "issue" +str(e)
				return render_template("signup.html", msg=msg)
			
			finally:
				if con is not None:
					con.close()
	else:
		return render_template("signup.html")

@app.route("/logout", methods=["GET"])
def logout():
    if "un" in session:
        session.pop("un")
    return redirect(url_for("login"))

@app.route("/feedback", methods=["POST"])
def feedback():
    feedback = request.json.get("feedback")
    save_feedback(feedback)
    return jsonify({"success": True})


if __name__ == "__main__":
    app.run(debug=True, use_reloader=True)

#--------------------------------


# import os
# import requests
# import sqlite3
# from flask import Flask, render_template, request, jsonify, redirect, url_for, session
# from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user
# from werkzeug.security import generate_password_hash, check_password_hash
# from werkzeug.utils import secure_filename

# app = Flask(__name__)
# app.secret_key = "sid"  # Change this to your own secret key

# # Configuration for Hugging Face Summarization API
# API_URL = "https://api-inference.huggingface.co/models/sshleifer/distilbart-cnn-12-6"
# HEADERS = {"Authorization": f"Bearer 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"}

# # Default summarization parameters
# DEFAULT_MIN_LENGTH = 30
# DEFAULT_MAX_LENGTH = 70

# # Set the upload folder and allowed extensions
# UPLOAD_FOLDER = 'uploads'
# ALLOWED_EXTENSIONS = {'txt', 'pdf', 'docx'}

# app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# # Initialize Flask-Login
# login_manager = LoginManager()
# login_manager.init_app(app)


# # User model
# class User(UserMixin):
#     def __init__(self, id, username, password):
#         self.id = id
#         self.username = username
#         self.password = password


# @login_manager.user_loader
# def load_user(user_id):
#     conn = sqlite3.connect('auth.db')
#     c = conn.cursor()
#     c.execute('SELECT * FROM users WHERE id = ?', (user_id,))
#     user_data = c.fetchone()
#     conn.close()
#     if user_data:
#         return User(user_data[0], user_data[1], user_data[2])
#     else:
#         return None


# # Function to check if the file extension is allowed
# def allowed_file(filename):
#     return '.' in filename and \
#            filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# # Function to summarize text using Hugging Face API
# def summarize_text(text, min_length=DEFAULT_MIN_LENGTH, max_length=DEFAULT_MAX_LENGTH, language="en"):
#     payload = {
#         "inputs": text,
#         "parameters": {"min_length": min_length, "max_length": max_length}
#     }

#     response = requests.post(API_URL, headers=HEADERS, json=payload)
#     if response.status_code == 200:
#         if isinstance(response.json(), list):
#             return response.json()[0]
#         else:
#             return response.json().get("summary_text")
#     else:
#         return None


# # Function to save feedback in the database
# def save_feedback(feedback):
#     conn = sqlite3.connect('feedback.db')
#     c = conn.cursor()
#     c.execute("INSERT INTO feedback (message) VALUES (?)", (feedback,))
#     conn.commit()
#     conn.close()


# # Function to initialize the database
# def init_db():
#     conn = sqlite3.connect('auth.db')
#     c = conn.cursor()
#     c.execute('''
#         CREATE TABLE IF NOT EXISTS users (
#             id INTEGER PRIMARY KEY AUTOINCREMENT,
#             username TEXT NOT NULL UNIQUE,
#             password TEXT NOT NULL
#         )
#     ''')
#     conn.commit()
#     conn.close()


# # Initialize the database when the app starts
# init_db()


# @app.route("/", methods=["GET", "POST"])
# @login_required
# def home():
#     if request.method == "POST":
#         # Check if text data is provided
#         data = request.form.get("data")
#         if data:
#             min_length = int(request.form.get("min_length", DEFAULT_MIN_LENGTH))
#             max_length = int(request.form.get("max_length", DEFAULT_MAX_LENGTH))
#             language = request.form.get("language", "en")
#             summarized_text = summarize_text(data, min_length=min_length, max_length=max_length, language=language)
#             if summarized_text:
#                 return render_template("home.html", result=summarized_text)
#             else:
#                 return render_template("home.html", error="Failed to summarize text")
#         else:
#             # Check if file is uploaded
#             if 'file' not in request.files:
#                 return render_template("home.html", error="No file part")

#             file = request.files['file']

#             # Check if file is empty
#             if file.filename == '':
#                 return render_template("home.html", error="No selected file")

#             # Check if file and its extension are allowed
#             if file and allowed_file(file.filename):
#                 filename = secure_filename(file.filename)
#                 file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
#                 file.save(file_path)

#                 # Read text from uploaded file
#                 with open(file_path, 'r') as file:
#                     data = file.read()

#                 # Get custom summarization parameters
#                 min_length = int(request.form.get("min_length", DEFAULT_MIN_LENGTH))
#                 max_length = int(request.form.get("max_length", DEFAULT_MAX_LENGTH))
#                 language = request.form.get("language", "en")

#                 # Summarize the text
#                 summarized_text = summarize_text(data, min_length=min_length, max_length=max_length, language=language)

#                 if summarized_text:
#                     return render_template("home.html", result=summarized_text)
#                 else:
#                     return render_template("home.html", error="Failed to summarize text")
#             else:
#                 return render_template("home.html", error="File type not allowed")
#     else:
#         return render_template("home.html")


# @app.route("/feedback", methods=["POST"])
# def feedback():
#     feedback = request.json.get("feedback")
#     save_feedback(feedback)
#     return jsonify({"success": True})


# @app.route("/login", methods=["GET", "POST"])
# def login():
#     if request.method == "POST":
#         username = request.form['username']
#         password = request.form['password']
#         conn = sqlite3.connect('auth.db')
#         c = conn.cursor()
#         c.execute('SELECT * FROM users WHERE username = ?', (username,))
#         user_data = c.fetchone()
#         conn.close()
#         if user_data and check_password_hash(user_data[2], password):
#             user = User(user_data[0], user_data[1], user_data[2])
#             login_user(user)
#             return redirect(url_for("home"))
#         else:
#             return render_template('login.html', error="Invalid username or password")
#     else:
#         return render_template("login.html")


# @app.route("/signup", methods=["GET", "POST"])
# def signup():
#     if request.method == "POST":
#         username = request.form['username']
#         password = request.form['password']
#         if not username or not password:
#             return render_template('signup.html', error="Username and password are required")
#         conn = sqlite3.connect('auth.db')
#         c = conn.cursor()
#         c.execute('SELECT * FROM users WHERE username = ?', (username,))
#         user_data = c.fetchone()
#         if user_data:
#             conn.close()
#             return render_template('signup.html', error="Username already exists")
#         hashed_password = generate_password_hash(password)
#         c.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, hashed_password))
#         conn.commit()
#         conn.close()
#         return redirect(url_for("login"))
#     else:
#         return render_template("signup.html")


# @app.route("/logout")
# @login_required
# def logout():
#     logout_user()
#     return redirect(url_for("login"))


# if __name__ == "__main__":
#     app.run(debug=True, use_reloader=True)




